class FillArrays {
    public byte[] ba;
    public int[] ia;
    public char[] ca;
    public short[] ha;
    public String[] sa;

    public void someArrays() {
        this.ba = new byte[] {20, 30, 40, 50};
        this.ia = new int[] {1,2,3,4,5,999,10324234};
        this.ca = new char[] {'a', 'b', 'x', 'z', 99};
        this.ha = new short[] {5, 10, 15, 20};
        this.sa = new String[] {"hello", "world"};
    }
}

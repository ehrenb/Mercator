Please remove this template if you only have a question or do not want to create a new issue.

### Describe what you wanted to do

- is this error specific to a single file?
- if possible give a minimal working example where the error happens

### Describe what you expected

### Describe what actually happened

### System Information

- Androguard Version: master
- Python Version: 2.7/3.5/...
- Operating System

### Further Log Files and Output

- please report logs, tracebacks and other useful information
- if possible report the files you tried to analyze!

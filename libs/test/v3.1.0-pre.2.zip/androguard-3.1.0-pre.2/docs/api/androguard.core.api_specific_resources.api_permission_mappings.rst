androguard.core.api_specific_resources.api_permission_mappings package
======================================================================

Submodules
----------

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings module
---------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api10 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api10
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api14 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api14
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api15 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api15
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api16 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api16
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api17 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api17
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api18 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api18
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api19 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api19
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api21 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api21
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api22 module
---------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api22
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api9 module
--------------------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings.api_permission_mappings_api9
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: androguard.core.api_specific_resources.api_permission_mappings
    :members:
    :undoc-members:
    :show-inheritance:

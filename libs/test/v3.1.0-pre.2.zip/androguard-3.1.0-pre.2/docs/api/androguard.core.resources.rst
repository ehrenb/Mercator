androguard.core.resources package
=================================

Submodules
----------

androguard.core.resources.public module
---------------------------------------

.. automodule:: androguard.core.resources.public
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: androguard.core.resources
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions package
===============================================================

Submodules
----------

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions module
-------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api10 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api10
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api14 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api14
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api15 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api15
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api16 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api16
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api17 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api17
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api18 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api18
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api19 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api19
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api21 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api21
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api22 module
-------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api22
    :members:
    :undoc-members:
    :show-inheritance:

androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api9 module
------------------------------------------------------------------------------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions.aosp_permissions_api9
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: androguard.core.api_specific_resources.aosp_permissions
    :members:
    :undoc-members:
    :show-inheritance:

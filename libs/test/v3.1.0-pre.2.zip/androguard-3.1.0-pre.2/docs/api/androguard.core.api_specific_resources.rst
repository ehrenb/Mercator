androguard.core.api_specific_resources package
==============================================

Subpackages
-----------

.. toctree::

    androguard.core.api_specific_resources.aosp_permissions
    androguard.core.api_specific_resources.api_permission_mappings

Module contents
---------------

.. automodule:: androguard.core.api_specific_resources
    :members:
    :undoc-members:
    :show-inheritance:

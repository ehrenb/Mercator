androguard.patch package
========================

Submodules
----------

androguard.patch.zipfile module
-------------------------------

.. automodule:: androguard.patch.zipfile
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: androguard.patch
    :members:
    :undoc-members:
    :show-inheritance:

androdis
========

.. program-output:: python ../androdis.py -h

.. automodule:: androdis
    :members:
    :undoc-members:
    :show-inheritance:

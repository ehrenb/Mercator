androlyze
=========

androlyze is a tool that spawns an IPython shell.

.. program-output:: python ../androlyze.py -h

.. automodule:: androlyze
    :members:
    :undoc-members:
    :show-inheritance:

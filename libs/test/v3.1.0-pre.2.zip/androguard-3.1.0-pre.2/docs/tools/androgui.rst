androgui
========

.. program-output:: python ../androgui.py -h

.. automodule:: androgui
    :members:
    :undoc-members:
    :show-inheritance:

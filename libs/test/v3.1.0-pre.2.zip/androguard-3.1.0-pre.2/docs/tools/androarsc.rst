androarsc
=========

.. program-output:: python ../androarsc.py -h

.. automodule:: androarsc
    :members:
    :undoc-members:
    :show-inheritance:
